export interface Produit {
    id: string, 
    nom: string,   
    description: string,  
    prix: number
}
