import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lien-details',
  templateUrl: './lien-details.component.html',
  styleUrls: ['../shared/shared-styles.css', './lien-details.component.css']
})
export class LienDetailsComponent implements OnInit {
  chemin = '';
  constructor() { }

  ngOnInit(): void {
  }

}
