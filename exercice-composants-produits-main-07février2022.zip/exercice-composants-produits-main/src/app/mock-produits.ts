import { Produit } from "./produit";

export const PRODUITS:Produit[] = [
    {id:'1', nom:'Produit #1', description:'Description du produit #1....', prix:10}, 
    {id:'2', nom:'Produit #2', description:'Description du produit #2....', prix:20}, 
    {id:'3', nom:'Produit #3', description:'Description du produit #3....', prix:30}, 
    {id:'4', nom:'Produit #4', description:'Description du produit #4....', prix:40}, 
    {id:'5', nom:'Produit #5', description:'Description du produit #5....', prix:50}
]